export const Constants = {
  'MIN_BET': 500,
  'INCREMENT_STEP': 500,
  'BET_OPTIONS': [
    {'id': 1, 'bet': '1st 12'},
    {'id': 2, 'bet': '2nd 12'},
    {'id': 3, 'bet': '3rd 12'},
    {'id': 4, 'bet': '0'},
    {'id': 5, 'bet': '1 to 18'},
    {'id': 6, 'bet': '19 to 36'},
    {'id': 7, 'bet': 'Even'},
    {'id': 8, 'bet': 'Odd'}
  ]
};

import {Injectable, OnInit} from '@angular/core';
import {Http, Headers} from "@angular/http";
import "rxjs/add/operator/map";
import {RouterModule} from "@angular/router";
import {Subject} from "rxjs/Subject";
import {BehaviorSubject} from "rxjs/BehaviorSubject";

// const BASE_URL = 'http://localhost:3000/Users';
const BASE_URL = 'api/Users/';
const header = {headers: new Headers({'Content-Type': 'application/json'})};

@Injectable()
export class UserService implements OnInit{

  // userIdSubject = new BehaviorSubject(-1);
  userNameSubject = new BehaviorSubject('Guest');
  balanceSubject = new BehaviorSubject(0);

  constructor(private http: Http) { }

  emitUserName(value) {
    this.userNameSubject.next(value);
  }

  emitBalance(value) {
    this.balanceSubject.next(value);
  }

  ngOnInit() {
    this.updateUser();
  }

  updateUser() {
    if (this.isLoggedIn()) {
      this.getUserById(localStorage.getItem('currentUser'))
        .subscribe(data => {
          if (data.length === 1) {
            this.emitUserName(data[0].name);
            this.emitBalance(data[0].balance);
          }
        });
    }
  }

  login(uniqueId) {
    let data = {'uniqueId': uniqueId};
    return this.http.post(BASE_URL, data, header)
      .map(res => res.json());
  }

  logout() {
    localStorage.removeItem('currentUser');
  }

  isLoggedIn() {
    if (localStorage.getItem('currentUser')) {
      return true;
    }
    return false;
  }

  getUserById(id) {
    return this.http.get(BASE_URL + '?userid=' + id)
      .map(res => res.json());
  }
}
